export default function Home() {
  return (
    <main>
      Olá mundo
    </main>
  )
}
